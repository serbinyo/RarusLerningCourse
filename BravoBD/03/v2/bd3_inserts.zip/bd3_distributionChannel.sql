INSERT INTO bd3.distributionChannel (id, name) VALUES (1, 'WhatsApp');
INSERT INTO bd3.distributionChannel (id, name) VALUES (2, 'Viber');
INSERT INTO bd3.distributionChannel (id, name) VALUES (3, 'Telegram');